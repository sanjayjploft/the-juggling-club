import React from "react";

export default function DashboardFooter() {
  return <div></div>;
}

import React from "react";

export default function DashboardHeader() {
  return <div></div>;
}
